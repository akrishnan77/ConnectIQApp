import { useState, useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";
import {
    View, Text, Image, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator
} from "react-native";
import { KEY, saveData, setCurrentTabIndex, setReloadDashboardData, setReloadTrainingData } from '../../utils/LocalStorage'; // Import functions from StorageService
import { getAuthToken } from "../../models/ApiService"
import { LandingScreenGrid } from "../../components/nrf_app/GridView";
import { app } from '@microsoft/teams-js';
import { getUserByEmail } from "../../utils/DummyData";
import TeamsSDK from "../../utils/TeamsSDK.jsx";
import { HomeTabs } from "../../utils/AppConstants.jsx";
//import { TeamsFxContext } from "../../components/Context";
//import { useData } from "@microsoft/teamsfx-react";
//import HarmanIcon from "../../components/nrf_app/HarmanIcon";

// Grid data
const gridItems = [
    {
        title: "Workforce Management",
        image: require("../../assets/images/home/img11.png"),
    },
    {
        title: "Clienteling",
        image: require("../../assets/images/home/img22.png"),
    },
    {
        title: "Inventory ",
        image: require("../../assets/images/home/img33.png"),
    },
    {
        title: "Store Operations",
        image: require("../../assets/images/home/img44.png")
    },
    {
        title: "Orders & Return",
        image: require("../../assets/images/home/img55.png")
    },
    {
        title: "mPOS",
        image: require("../../assets/images/home/img66.png"),
    },
];

export default function DashboardGrid() {
    const navigate = useNavigate();

    const [loading, setLoading] = useState(true);
    const [error, setErrorMsg] = useState(null);
    const [userEmail, setUserEmail] = useState('');
    const [userName, setUserName] = useState('');
    const [userProfile, setUserProfile] = useState('');

    setCurrentTabIndex(HomeTabs.DASHBOARD)
    setReloadDashboardData(true)
    setReloadTrainingData(true)

    const getUserEmail = async () => {
        let email = ''
        try {
            // app.initialize(() => {
            //   console.log("Teams SDK initialized successfully!");
            // });
            // Initialize Microsoft Teams SDK and get context
            //TeamsSDK.initialize()
            //const context = await TeamsSDK.getContext()
            //TeamsSDK.setAppTitle('TestTitle')
            await app.initialize()
            const context = await app.getContext()
            // The user's email is typically in the `userPrincipalName`
            const emailUser = context.user.userPrincipalName
            if (emailUser) {
                email = emailUser
                //setUserEmail(context.user.displayName)
            }
        } catch (error) {
            console.error("Error initializing Teams SDK:", error);
            //throw error
        }
        return email
    }

    const getDisplayName = async () => {
        // try {
        //     if (teamsUserCredential) {
        //         const userInfo = await teamsUserCredential.getUserInfo();
        //         //setUserEmail(userInfo.displayName)
        //         return userInfo;
        //     }
        // } catch (error) {
        //     console.error("Error getDisplayName:", error);
        // }
    }

    // Function to fetch AuthToken
    const fetchAuthToken = async () => {
        try {
            // Pratheesh.Devan@htlbeta.onmicrosoft.com
            // mayuranil.prasad@htlbeta.onmicrosoft.com
            // prakash.salawria@htlbeta.onmicrosoft.com
            // praveen.rangaswamy@htlbeta.onmicrosoft.com
            // Emily.Johnson@htlbeta.onmicrosoft.com
            // John.Smith@htlbeta.onmicrosoft.com
            // Robert.Williams@htlbeta.onmicrosoft.com

            const email = await getUserEmail()
            //const email = 'John.Smith@htlbeta.onmicrosoft.com'
            const userInfo = getUserByEmail(email)
            setUserName(userInfo.name)
            setUserProfile(userInfo.profileIcon)

            const responseData = await getAuthToken(email); // Fetch data using the API utility
            if (JSON.stringify(responseData).includes("access_token")) {
                saveData(KEY.USER_TOKEN, responseData.access_token)
                saveData(KEY.USER_EMAIL, email)
                saveData(KEY.USER_ROLE, userInfo.role)
                saveData(KEY.USER_NAME, userInfo.name)
            }
            console.log(responseData);
            setLoading(false);
        } catch (error) {
            console.log(error);
            //setErrorMsg('Something went wrong, please check if you have required access for the app or contact your administrator');
            setErrorMsg(error)
            setLoading(false);
        }
    };

    // Fetch data when the component mounts
    useEffect(() => {
        fetchAuthToken();
    }, []);  // Empty array means this effect runs only once after the first render

    if (loading) {
        return (
            <View style={{
                width: '100%', height: '100%',
                justifyContent: "center", alignItems: "center"
            }}>
                {/* <Text>Loading..</Text> */}
                <ActivityIndicator size="large" color="#0000ff" />
            </View>
        );
    }

    if (error) {
        return (
            <View style={{
                width: '100%', height: '100%', padding: 32,
                justifyContent: "center", alignItems: "center", textAlign: 'center'
            }}>
                <Text>{error}</Text>
            </View>
        );
    }

    const handleItemSelected = (item, index) => {
        if (index === 0) {
            navigate("/home");
            //navigation.navigate("screens/front_desk/front_desk_screen");
        } else {
            navigate("/comingSoon", { state: item.title })
        }
    };

    return (
        <View style={styles.container}>
            {/* <ImageWithTextAndLogo /> */}
            <Toolbar
                name={userName}
                profile={userProfile}
            />
            <Image
                source={require("../../assets/images/home/icon_harman_banner2.png")} // Replace with the correct path to your local image
                style={{ width: '328', height: 45, marginTop: 16, marginBottom: 16, alignSelf: "center" }}
            />
            {/* <Text style={{
                color: '#266098', fontSize: 24, fontWeight: '500',
                marginTop: 32, marginBottom: 16, textAlign: "center"
            }}>
                Harman Connect IQ {userEmail}
            </Text> */}
            <LandingScreenGrid
                gridItems={gridItems}
                itemSelected={handleItemSelected}
                columns={3}
            />
        </View>
    );
}

function Toolbar({ profile, name }) {
    const navigate = useNavigate();

    return (
        <View style={toolbarStyle.container}>
            <Image
                source={profile} // Replace with the correct path to your local image
                style={toolbarStyle.profilePic}
            />
            <View
                style={{
                    flexDirection: "column",
                    alignItems: "flex-start",
                    flex: 1,
                }}
            >
                <Text style={toolbarStyle.title}>{name}</Text>
                <Text style={{ fontSize: 13, fontWeight: "400", color: "#fff" }}>
                    General Store, Cincinnati
                </Text>
            </View>
            {/* Emily.Johnson John Smith*/}
            {/* Right Side: Home Icon */}

            <TouchableOpacity
                onPress={() => { navigate('/chatBot') }}>
                <Image
                    source={require("../../assets/images/home/icon_bot.png")} // Replace with the correct path to your local image
                    style={[toolbarStyle.iconSmallest, { marginEnd: 16 }]}
                />
            </TouchableOpacity>
            <TouchableOpacity
                onPress={() => { navigate('/notifications') }}>
                <Image
                    source={require("../../assets/images/home/icon_notification.png")} // Replace with the correct path to your local image
                    style={toolbarStyle.iconSmallest}
                />
            </TouchableOpacity>
        </View>
    );
}

const toolbarStyle = StyleSheet.create({
    container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: 16,
        paddingBottom: 16,
        paddingTop: 16,
        backgroundColor: "#5B57C7",
    },
    profilePic: {
        width: 40,
        height: 40,
        borderRadius: 20,
        marginRight: 10,
    },
    title: {
        fontSize: 16,
        fontWeight: "500",
        color: '#fff'
    },
    iconSmallest: {
        width: 24, // Adjust icon size as needed
        height: 24
    },
});

// ImageWithTextAndLogo Component
// const ImageWithTextAndLogo = () => {
//     return (
//         <View style={styles.headerContainer}>
//             <Image
//                 source={require("../assets/images/home/main_header.png")}
//                 style={styles.mainImage}
//                 resizeMode="cover"
//             />
//             <HarmanIcon style={styles.logo} />
//             <View style={styles.headerText}>
//                 <Text style={styles.title}>Super App</Text>
//                 <Text style={styles.titleBig}>
//                     Hospitality
//                 </Text>
//             </View>
//         </View>
//     );
// };

// GridView Component
const GridView = ({ itemSelected }) => {
    const numColumns = 2; // You can change this to any number of columns
    // GridItemCard Component
    const GridItemCard = ({ item, index }) => {
        return (
            <TouchableOpacity
                onPress={() => itemSelected(item, index)}
                style={styles.gridItem}>
                <Image
                    source={item.image}
                    style={styles.gridItemImage}
                    resizeMode="cover"
                />
                <Text style={styles.gridItemText}>{item.title}</Text>
            </TouchableOpacity>
        );
    };

    return (
        <FlatList
            data={gridItems}
            numColumns={numColumns}
            renderItem={GridItemCard}
            keyExtractor={(item, index) => index.toString()}
            contentContainerStyle={styles.gridContainer}
        />
    );
};

// Styles
const styles = StyleSheet.create({
    card: {
        padding: 0,
        marginVertical: 8,
        marginHorizontal: 8,
        backgroundColor: '#fff',
        borderRadius: 4,
        elevation: 2, // Android shadow
        shadowColor: '#000', // iOS shadow
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.3,
        shadowRadius: 1,
    },
    title: { color: "white", fontSize: 16 },
    titleBig: { color: "white", fontSize: 20, fontWeight: "bold" },
    container: {
        flex: 1,
        flexDirection: "column",
    },
    headerContainer: {
        width: "100%",
        height: 300,
        justifyContent: "flex-end",
        alignItems: "center",
    },
    mainImage: {
        width: "100%",
        height: "100%",
        position: "absolute",
    },
    logo: {
        width: 101,
        height: 60,
        position: "absolute",
        bottom: 16,
        right: 16,
    },
    headerText: {
        position: "absolute",
        bottom: 16,
        left: 16,
        flexDirection: "column",
    },
    gridContainer: {
        paddingHorizontal: 16,
        paddingVertical: 16,
        flex: 1,
    },
    gridItem: {
        flex: 1,
        margin: 8,
        backgroundColor: "white",
        borderRadius: 8,
        alignItems: "center",
        boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1), 0px -0.1px 2px rgba(0, 0, 0, 0.1)',
    },
    gridItemImage: {
        width: "100%",
        height: 150,
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
    },
    gridItemText: {
        padding: 8,
        fontSize: 16,
        fontWeight: "400",
    },
});
