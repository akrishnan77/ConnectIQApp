import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  View, Text,
  Image,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Modal,
  FlatList,
  ActivityIndicator,
} from "react-native";

// Import assets
import RobotIcon from "../../assets/images/task/icon_robot_blue.png";
import UploadIcon from "../../assets/images/task/icon_upload.png";
import DeleteIcon from "../../assets/images/task/icon_delete.png";
import CheckIcon from "../../assets/images/task/icon_check.png";
import AnalyticsIcon from "../../assets/images/task/icon_ai_new.png";
import CheckBoxSelectedIcon from "../../assets/images/task/icon_checkbox.png";
import CheckboxUnselected from "../../assets/images/task/icon_uncheck.png";

import TaskModel from '../../models/TaskModel';
import { uploadChecklistData } from "../../models/ApiService";
import Utils from "../../utils/Utils";
import { Toolbar, CustomAlert } from "../../components/nrf_app/Toolbar";
import { setReloadDashboardData } from "../../utils/LocalStorage";

const TitleIcon = require("../../assets/images/task/icon_task_title.png"); // Replace with actual path
const ViewMoreIcon = require("../../assets/images/task/icon_viewmore.png"); // Replace with actual path
const ViewLessIcon = require("../../assets/images/task/icon_viewless.png"); // Replace with actual path

const TaskDetail = () => {
  const navigate = useNavigate();
  const [alert, setAlert] = useState({ visible: false, message: '', type: '' });

  const [taskDetails, setTaskDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const { taskIdnew } = useParams(); // Get taskId from the URL

  const [currentChecklistIndex, setCurrentChecklistIndex] = useState(0);
  const [uploadedImages, setUploadedImages] = useState([]);
  const [showMore, setShowMore] = useState(false);
  const [isChecked, setIsChecked] = useState(false);
  const [isChecklistVisible, setChecklistVisible] = useState(false);
  const [error, setError] = useState(null);
  const [checkListDataArray, setCheckListDataArray] = useState([]);
  let uploadedCheckListDataArray = [];

  const toggleCheckbox = () => {
    setIsChecked(!isChecked);
    currentChecklist.status = !currentChecklist.status
  };
  const closeModal = () => {
    setChecklistVisible(false); // Close the modal
  };

  const taskId = parseInt(taskIdnew, 10);
  console.log("Task ID is :", taskId);

  useEffect(() => {
    const loadTaskDetails = async () => {
      try {
        setLoading(true); // Start loading
        const taskModel = new TaskModel(taskId); // Initialize the TaskModel
        const fetchedTaskDetails = await taskModel.fetchTaskDetails(); // Await API or fallback JSON data
        setTaskDetails(fetchedTaskDetails); // Set the task details
        
      } catch (err) {
        setError(err.message); // Capture and store errors
      } finally {
        setLoading(false); // End loading
      }
    };

    loadTaskDetails(); // Call the async function
  }, [taskId]); // Re-fetch data if the taskIdnew changes

  if (loading) {
    return (
      <View style={{
        width: '100%', height: '100%',
        justifyContent: "center", alignItems: "center"
      }}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Error: {error}</Text>
      </View>
    );
  }
  // Ensure taskDetails is available before rendering the rest of the UI
  if (!taskDetails) {
    return (
      <View style={styles.noDataContainer}>
        <Text style={styles.noDataText}>No task details available.</Text>
      </View>
    );
  }

  console.log(taskDetails)
  const checklist = taskDetails.checklist || [];
  const currentChecklist = checklist[currentChecklistIndex] || {};

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onloadend = () => {
      // const base64Image = reader.result.split(',')[1];
      const base64Image = reader.result;

      const uploadedImageData = {
        id: 0,
        imageName: file.name,
        imageBase64: base64Image,         // The base64 encoded image data
        ImageUri: URL.createObjectURL(file) // URL to access the image
      };
      setUploadedImages((prev) => [...prev, uploadedImageData]);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  // Convert priority number to text
  const getPriorityText = (priority) => {
    switch (priority) {
      case 1:
        return "Low";
      case 2:
        return "Medium";
      case 3:
        return "High";
      case 4:
        return "Urgent";
      default:
        return "Medium";
    }
  };

  const getPriorityColor = (priority) => {
    if (priority === 4) return styles.highPriority;
    if (priority === 3) return styles.highPriority;
    if (priority === 2) return styles.mediumPriority;
    return styles.lowPriority;
  };

  const getAiData = () => {
    console.log("currentChecklist is =", currentChecklist);
    if (!currentChecklist) return null;

    let aiDescription = '';
    let aiDetail = '';

    switch (currentChecklist.checklistType) {
      case 0:
        aiDescription = "FIFO (First-In, First-Out) Always place older stock in front of newer stock to ensure freshness and minimize waste.";
        aiDetail = "Data collected on inventory management resource repository";
        break;
      case 1:
        aiDescription = "FIFO (First-In, First-Out) Always place older stock in front of newer stock to ensure freshness and minimize waste.";
        aiDetail = "Data collected on inventory management resource repository";
        break;
      case 2:
        aiDescription = "FIFO (First-In, First-Out) Always place older stock in front of newer stock to ensure freshness and minimize waste.";
        aiDetail = "Data collected on inventory management resource repository";
        break;
      default:
        aiDescription = "FIFO (First-In, First-Out) Always place older stock in front of newer stock to ensure freshness and minimize waste.";
        aiDetail = "Data collected on inventory management resource repository";
        break;
    }

    return {
      aiDescription,
      aiDetail
    };
  };

  const aiData = getAiData();

  const STATUS_MAPPING = {
    1: { text: "Yet to Start", color: "#616161" }, // Gray
    2: { text: "In Progress", color: "#BC4B09" }, // Brown
    3: { text: "Completed", color: "#0E700E" },   // Green
    4: { text: "Over Due", color: "#C50F1F" },    // Red
  };

  const getStatusDetails = (status) => {
    const statusNumber = Number(status);
    return STATUS_MAPPING[statusNumber] || { text: "Yet To Start", color: "#616161" }; // Default fallback
  };

  const handleImageUploadButton = () => {
    document.getElementById("imageInput").click(); // Simulate file input click
  };

  // Handle delete image
  const handleDeleteImage = (id) => {
    setUploadedImages((prev) => prev.filter((image) => image.id !== id));
  };

  // Handle scan button click
  const handleScanClick = () => {
    const url =
      "https://websdk.demos.scandit.com/?_gl=1*1o3c3lj*_gcl_au*MTg5OTE4MzU4LjE3MzE1ODI5NzY.*_ga*NjUxMzIwNDY2LjE3MzE1ODI5NzA.*_ga_TXJZRPJJ0T*MTczMTU4Mjk3MC4xLjEuMTczMTU4MzMzOS41Ni4wLjA.";
    window.open(url, "_blank");
  };

  const handleToggleMore = () => {
    setShowMore(!showMore);
  };

  const handleViewAllPress = () => {
    // Add your logic for the "View All" button here
    console.log("View All pressed");
    setChecklistVisible(true); // Open the modal
  };

  const handleNextOrComplete = async () => { // Mark the function as async
    if (currentChecklistIndex === taskDetails.checklist.length - 1) {
      if (taskDetails.status !== 3) {
        taskDetails.status = 3;
        await manageChecklistUploadList(); // Use await for asynchronous functions
        await uploadCheckList(); // No await if it's synchronous
        //alert("Error", "Something went wrong. Please try again.");
        // navigate('/home');
        setReloadDashboardData(true)
        setAlert({ visible: true, message: 'Task Updated successfully!', type: 'success' });
      }
    } else {
      setCurrentChecklistIndex((prev) =>
        Math.min(taskDetails.checklist.length - 1, prev + 1)
      );
      if (taskDetails.status !== 3) {
        await manageChecklistUploadList(); // Await the asynchronous function
      }
    }
  };

  const isCompleteDisabled = !taskDetails.checklist.every(item => item.status === true);

  const manageChecklistUploadList = async () => {
    const localChecklistArray = [...checkListDataArray];  // Make a copy of the current array

    const appendChecklist = (checklistType, attachment = null) => {
      // Create a new checklist
      console.log("current check list id", currentChecklist);
      const uploadedCheckList = Utils.uploadChecklistByType(checklistType);
      uploadedCheckList.id = currentChecklist.id;
      uploadedCheckList.status = currentChecklist.status;
      uploadedCheckList.checklistType = currentChecklist.checklistType;

      // Add attachments if applicable
      if (attachment) {
        uploadedCheckList.attachements = uploadedCheckList.attachements || [];
        uploadedCheckList.attachements.push(attachment);
      }

      // Append to the local array without resetting it
      localChecklistArray.push(uploadedCheckList);  // Directly append
    };

    if (currentChecklist.checklistType === 0) {
      appendChecklist(0);
    }

    if (currentChecklist.checklistType === 1) {
      let attachment = null;
      if (uploadedImages.length > 0) {
        const uploadedImageData = uploadedImages[uploadedImages.length - 1];
        if (currentChecklist.attachements && currentChecklist.attachements[0]) {
          // The ID exists and is not empty
          attachment = {
            id: currentChecklist.attachements[0].id,
            imageName: uploadedImageData.imageName,
            imageBase64: uploadedImageData.imageBase64,
            ImageUri: uploadedImageData.ImageUri,
          };
        } else {
          // The ID is empty or does not exist
          attachment = {
            id: 0,
            imageName: uploadedImageData.imageName,
            imageBase64: uploadedImageData.imageBase64,
            ImageUri: uploadedImageData.ImageUri,
          };
        }

      }
      appendChecklist(1, attachment);
    }

    if (currentChecklist.checklistType === 2) {
      appendChecklist(2);
    }

    // Update the state with the final array
    setCheckListDataArray(localChecklistArray);

    // Append localChecklistArray data to uploadedCheckListDataArray
    uploadedCheckListDataArray.push(...localChecklistArray);

    // Log the final length and array
    console.log("UploadedFinalone complete checkListDataArray length:", uploadedCheckListDataArray.length);
    console.log("UploadedFinalone complete checkListDataArray:", uploadedCheckListDataArray);
  };

  const uploadCheckList = async () => {
    setTimeout(() => {
      console.log("UploadedFinalone complete checkListDataArray length:", uploadedCheckListDataArray.length);
      console.log("UploadedFinalone complete checkListDataArray", uploadedCheckListDataArray);
    }, 4);

    if (uploadedCheckListDataArray.length > 0) {
      setLoading(true);
      try {
        const responseData = await uploadChecklistData(taskDetails, uploadedCheckListDataArray); // Fetch data using the API utility
        setLoading(false);
      } catch (error) {
        setLoading(false);
      }
    }
  };

  return (
    <ScrollView style={styles.container}
      bounces={false} // Disable bounce on iOS
      overScrollMode="never"
      horizontal={false}
      showsHorizontalScrollIndicator={false} >
      {/* Header */}
      <View style={styles.content}>
        {/* <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigate(-1)} // Navigate to the previous screen
          >
            <Image
              source={require("../../assets/images/home/icon_back.png")}
              style={styles.backArrow}
            />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Task Details</Text>
          <Image source={RobotIcon} style={styles.robotIcon} />
        </View> */}
        <Toolbar
          title={'Task Details'}
        />

        {alert.visible && (
          <CustomAlert
            message={alert.message}
            type={alert.type}
            onClose={() => setAlert({ visible: false, message: '', type: '' })}
          />
        )}


        <View style={styles.taskDetailscard}>


          <View style={styles.titleContainer}>
            {/* Title Row with Icon */}
            <View style={styles.titleRow}>
              <Text style={styles.title}>{taskDetails.title}</Text>
              <Image source={TitleIcon} style={styles.titleIcon} />
            </View>

            {/* Status and Priority Row */}
            <View style={styles.statusPriorityRow}>
              {/* Status Text on Left */}
              <Text style={[styles.status, { color: getStatusDetails(taskDetails.status).color }]}>
                {getStatusDetails(taskDetails.status).text}
              </Text>

              {/* Priority Chip on Right */}
              <View style={styles.priorityChip}>
                <Text style={[styles.priorityText, getPriorityColor(taskDetails.priority)]}>
                  {getPriorityText(taskDetails.priority)}
                </Text>
              </View>
            </View>
          </View>


          {/* Divider */}
          <View style={styles.divider} />

          {/* Show More Content */}
          {showMore && (
            <>
              {/* Assigned By */}
              <View style={styles.detailRow}>
                <Text style={styles.label}>Assigned By:</Text>
                <Text style={styles.value}>{taskDetails.userName}</Text>
              </View>

              {/* Category */}
              <View style={styles.detailRow}>
                <Text style={styles.label}>Category:</Text>
                <Text style={styles.value}>{taskDetails.taskCategory}</Text>
              </View>

              {/* Due By */}
              <View style={styles.detailRow}>
                <Text style={styles.label}>Due By:</Text>
                <Text style={styles.value}>{taskDetails.dueDate}</Text>
              </View>
            </>
          )}

          <View style={styles.toggleContainer}>
            <TouchableOpacity onPress={handleToggleMore} style={styles.toggleInnerContainer}>
              <Image source={showMore ? ViewLessIcon : ViewMoreIcon} style={styles.toggleIcon} />
              <Text style={styles.toggleText}>{showMore ? "View Less" : "View More"}</Text>
            </TouchableOpacity>
          </View>
        </View>


        <View style={styles.checklistContainer}>
          {/* <Text style={styles.checklistTitle}>Task Checklist</Text> */}
          <View style={styles.checkListHeader}>
            {/* Title on the left */}
            <Text style={styles.checklistTopTitle}>Task Checklist</Text>

            {/* View All button with arrow image on the right */}
            <TouchableOpacity style={styles.viewAllContainer} onPress={handleViewAllPress}>
              <Text style={styles.viewAllText}>View All</Text>
              <Image
                source={require("../../assets/images/task/icon_right_arrow.png")} // Replace with the path to your arrow icon
                style={styles.arrowIcon}
              />

            </TouchableOpacity>
          </View>


          {/* Modal for Checklist */}
          <Modal
            visible={isChecklistVisible}
            animationType="fade"
            transparent={true}
            onRequestClose={closeModal}
          >
            <View style={styles.modalOverlay}>
              <View style={styles.modalContent}>
                {/* Header */}
                <View style={styles.modalHeader}>
                  <Text style={styles.modalTitle}>Task Checklist</Text>
                  <TouchableOpacity onPress={closeModal} style={styles.closeButton}>
                    <Text style={styles.closeButtonText}>✕</Text>
                  </TouchableOpacity>
                </View>

                {/* Checklist Items */}
                <FlatList
                  data={taskDetails.checklist} // Render checklist from JSON
                  renderItem={({ item }) => (
                    <Text style={styles.modalItemText}>{item.title}</Text>
                  )}
                  keyExtractor={(item, index) => index.toString()}
                />
              </View>
            </View>
          </Modal>



          <View style={styles.checklistItem}>
            {/* Checkbox */}
            <View style={styles.checklistItemContainer}>
              {/* Checkbox */}
              <TouchableOpacity onPress={toggleCheckbox} style={styles.checkbox}>
                <Image
                  source={currentChecklist.status ? CheckBoxSelectedIcon : CheckboxUnselected}
                  style={styles.checkboxImage}
                />
              </TouchableOpacity>

              {/* Title */}
              <Text style={styles.checklistItemTitle}>{currentChecklist.title}</Text>
            </View>

            {/* Right side: Progress */}
            <Text style={styles.checklistProgress}>{currentChecklistIndex + 1}/{taskDetails.checklist.length}</Text>

          </View>
          <Text style={styles.checklistDescription}>
            {currentChecklist.description}
          </Text>
          <Text style={styles.estimatedTime}>
            Estimated time: {currentChecklist.estimatedTimeInMin} minutes
          </Text>

          {/* Action Buttons */}
          {currentChecklist.checklistType === 1 && (
            <>
              <TouchableOpacity
                style={styles.uploadButton}
                onPress={handleImageUploadButton}
              >
                <Image source={UploadIcon} style={styles.uploadIcon} />
                <Text style={styles.uploadText}>Upload Picture</Text>
              </TouchableOpacity>
              <input
                type="file"
                id="imageInput"
                accept="image/*"
                style={{ display: "none" }}
                onChange={handleImageUpload}
              />
            </>
          )}
          {currentChecklist.checklistType === 2 && (
            <TouchableOpacity
              style={styles.scanButton}
              onPress={handleScanClick}
            >
              <Text style={styles.scanButtonText}>Scan Barcode</Text>
            </TouchableOpacity>
          )}

          {/* Display Uploaded Images */}
          {/* {uploadedImages.map((image) => (
          <View key={image.id} style={styles.uploadedImageContainer}>
            <Image source={{ uri: image.imageBase64 }} style={styles.uploadedImage} />
            <View style={styles.imageButtons}>
              <TouchableOpacity onPress={() => handleDeleteImage(image.id)}>
                <Image source={DeleteIcon} style={styles.icon} />
              </TouchableOpacity>
              <TouchableOpacity>
                <Image source={CheckIcon} style={styles.icon} />
              </TouchableOpacity>
            </View>
          </View>
        ))} */}

          {currentChecklist.checklistType === 1 && (
            // Check if there are uploaded images first
            uploadedImages.length > 0 ? (
              uploadedImages.map((image) => (
                <View key={image.id} style={styles.uploadedImageContainer}>
                  <Image source={{
                    uri: image.imageBase64

                  }} style={styles.uploadedImage} />
                  <View style={styles.imageButtons}>
                    <TouchableOpacity onPress={() => handleDeleteImage(image.id)}>
                      <Image source={DeleteIcon} style={styles.icon} />
                    </TouchableOpacity>
                    <TouchableOpacity>
                      <Image source={CheckIcon} style={styles.icon} />
                    </TouchableOpacity>
                  </View>
                </View>
              ))
            ) : (
              // If no uploaded images, check for attachments in taskDetails.checklist
              taskDetails.checklist[currentChecklistIndex]?.attachements?.length > 0 &&
              taskDetails.checklist[currentChecklistIndex].attachements.map((attachment) => (
                <View key={attachment.id} style={styles.uploadedImageContainer}>
                  <Image
                    source={{
                      uri: attachment.imageBase64
                    }} style={styles.uploadedImage} />

                  {/* source={{
                    uri: `data:image/svg+xml;base64,${attachment.imageBase64}`,
                  } style={styles.uploadedImage}}/> */}
                  <View style={styles.imageButtons}>
                    <TouchableOpacity onPress={() => handleDeleteImage(attachment.id)}>
                      <Image source={DeleteIcon} style={styles.icon} />
                    </TouchableOpacity>
                    <TouchableOpacity>
                      <Image source={CheckIcon} style={styles.icon} />
                    </TouchableOpacity>
                  </View>
                </View>
              ))
            )
          )}

          {/* AI Insights Section */}
          <View style={styles.aiAnalyticsContainer}>
            <View style={styles.rowContainer}>
              <Image source={AnalyticsIcon} style={styles.analyticsIcon} />
              <Text style={styles.aiText}>AI Insights</Text>
            </View>
            {/* <Text style={styles.aiText}>AI Analytics</Text> */}
            {/* <Image source={AnalyticsIcon} style={styles.analyticsIcon} /> */}
            <View style={styles.aiDiscriptionContainer}>
              <Text style={styles.aiTitle}>{currentChecklist.aiDescription || aiData.aiDescription}</Text>
              <Text style={styles.aiDescription}>{currentChecklist.aiTitle || aiData.aiDetail}</Text>
            </View>
            <View style={styles.aiButtons}>
              <TouchableOpacity style={styles.customButton} onPress={() => { }}>
                <Text style={styles.customButtonText}>Warehouse Stocking Layout</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.navigationButtonContainer}>
        {/* Previous Button */}
        <TouchableOpacity
          style={[
            styles.previousButton,
            currentChecklistIndex === 0 && styles.disabledButton,
          ]}
          onPress={() =>
            setCurrentChecklistIndex((prev) => Math.max(0, prev - 1))
          }
          disabled={currentChecklistIndex === 0}
        >
          <Text
            style={[
              styles.previousbuttonText,
              currentChecklistIndex === 0 && styles.disabledButtonText,
            ]}
          >
            Previous
          </Text>
        </TouchableOpacity>

        {/* Next/Complete Button */}
        {/* <TouchableOpacity
        style={styles.nextButton}
        onPress={handleNextOrComplete}>
      
        <Text style={styles.navbuttonText}>
          {currentChecklistIndex === taskDetails.checklist.length - 1 ? 'Complete' : 'Next'}
        </Text>
      </TouchableOpacity> */}

        <TouchableOpacity
          style={[
            styles.navButton,
            currentChecklistIndex === taskDetails.checklist.length - 1 && isCompleteDisabled || 
            (currentChecklistIndex === taskDetails.checklist.length - 1 && taskDetails.status === 3)
              ? styles.disabledCompleteButton
              : null,
          ]}
          disabled={
            currentChecklistIndex === taskDetails.checklist.length - 1 && isCompleteDisabled
          }
          onPress={handleNextOrComplete}
        >
          <Text style={styles.navbuttonText}>
            {currentChecklistIndex === taskDetails.checklist.length - 1 ? 'Complete' : 'Next'}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>

  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FAFAFA",
    padding: 0,

    width: "100%", // Ensures the container uses full screen width
    height: "100%",
    overflowX: "hidden", // Prevent horizontal scrolling by hiding overflow
    paddingBottom: 0,
  },
  content: {
    width: "100%", // Ensure the content spans the full width of the screen
    //justifyContent: "",
    padding: 0,
    height: "100%",
    backgroundColor: "#fff"
  },

  errorContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F5F5",
  },
  errorText: {
    fontSize: 16,
    color: "#C50F1F",
    textAlign: "center",
  },
  noDataContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F5F5",
  },
  noDataText: {
    fontSize: 16,
    color: "#616161",
  },

  detail: {
    fontSize: 16,
    marginBottom: 4,
    color: "#333333",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
    alignItems: "center",
    width: "100%",
    paddingBottom: 8, // Adds spacing between content and the bottom border
    borderBottomWidth: 1, // Adds the bottom line
    borderBottomColor: "#ccc", // Light grey color for the line
    height: 70,      // Explicit height for a taller header
  },
  backButton: {
    justifyContent: "center",
    alignItems: "center",
  },
  backArrow: {
    width: 20,
    height: 15,
    left: 15,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#000",
    left: 60,
    flex: 1, // Allow title to take up remaining space
    textAlign: "left",
  },
  robotIcon: { width: 30, height: 30, right: 20, },
  taskDetailscard: {
    backgroundColor: "#ffffff",
    borderRadius: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    padding: 16,
    margin: 16,
    elevation: 2,
  },
  titleContainer: {
    marginBottom: 16,
  },
  titleRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333333",
  },
  titleIcon: {
    width: 24,
    height: 24,
    resizeMode: "contain",
    marginLeft: 6,
  },
  statusPriorityRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 12, // Spacing below title row
  },
  status: {
    fontSize: 14,
    fontWeight: 400,
    // color: "#757575", // Gray for status text
  },

  priorityChip: {

    paddingHorizontal: 8,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: "#FDF3F4",
    alignItems: "center",
  },
  priorityText: {
    fontSize: 14,
    fontWeight: "bold",
  },
  highPriority: {
    color: "#960B18",
  },
  mediumPriority: {
    color: "#8A3707",
  },
  lowPriority: {
    color: "#0C5E0C",
  },

  divider: {
    height: 1,
    backgroundColor: "#E0E0E0",
    marginVertical: 8,
  },
  detailRow: {
    flexDirection: "column", // Stack items vertically
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    color: "#757575",
  },
  value: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#212121",
    marginTop: 4, // Add spacing between label and value
  },
  toggleContainer: {
    justifyContent: "center", // Centers the entire view horizontally
    alignItems: "center", // Centers the content vertically
    marginTop: 16, // Adds spacing above the toggle
  },
  toggleInnerContainer: {
    flexDirection: "row", // Aligns the icon and text horizontally
    alignItems: "center", // Ensures the icon and text are vertically aligned
  },
  toggleIcon: {
    width: 16, // Width of the toggle icon
    height: 16, // Height of the toggle icon
    marginRight: 8, // Space between the icon and text
    marginTop: 4,
  },
  toggleText: {
    fontSize: 14, // Text size
    fontWeight: "500", // Semi-bold text
    color: "#5B57D4", // Purple text color for the toggle
  },

  statusContainer: { marginBottom: 16, marginTop: 20, },
  statusTitle: { fontSize: 16, fontWeight: "bold", marginBottom: 8 },
  statusButtonContainer: { flexDirection: "row", flexWrap: "wrap" },
  statusButtonText: { fontSize: 14, color: "#fff", fontWeight: "bold" },
  checklistContainer: {
    // backgroundColor: "#ffffff",
    borderRadius: 8,
    // shadowColor: "#000",
    //shadowOffset: { width: 0, height: 2 },
    //shadowOpacity: 0.1,
    // shadowRadius: 4,
    padding: 16,
    margin: 16,
    elevation: 2,
    paddingBottom: 80,
    //  marginBottom: 40,
  },

  checkListHeader: {
    flexDirection: "row", // Align elements horizontally
    justifyContent: "space-between", // Space between title and "View All"
    alignItems: "center", // Vertically align title and button
    marginBottom: 16, // Space below the header
  },
  checklistTopTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#242424",
  },
  checklistItem: {
    padding: 0,
    //borderBottomWidth: 1,
    //borderColor: '#ddd',
  },
  viewAllContainer: {
    flexDirection: "row", // Align "View All" text and arrow horizontally
    alignItems: "center", // Vertically align text and arrow
  },
  viewAllText: {
    fontSize: 14,
    color: "#5B57C7", // Matches the checklist item text color
    fontWeight: "500",
    marginRight: 2, // Space between text and arrow
  },
  arrowIcon: {
    width: 16,
    height: 16,
    resizeMode: "contain", // Ensure the arrow icon scales properly
  },

  checklistItemContainer: {
    flexDirection: "row", // Align checkbox and title horizontally
    alignItems: "center",
    marginBottom: 10,
    // flex: 1, // Allow left side to take available space
    // marginVertical: 16, // Spacing between checklist items
    //  height: 20,
    //justifyContent: "center", // Space out elements
  },
  checkbox: {
    marginRight: 8, // Exact 8px space between checkbox and title
  },
  checkboxImage: {
    width: 24,
    height: 24,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    width: "90%",
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 15,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
    paddingBottom: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold",
  },
  closeButton: {
    padding: 5,
  },
  closeButtonText: {
    fontSize: 18,
    color: "#888",
  },
  modalItemText: {
    fontSize: 16,
    color: "#333",
    marginBottom: 10,
  },

  checklistTitle: { fontSize: 16, fontWeight: "bold", color: "#424242" },
  checklistProgress: {
    fontSize: 14, right: 2, textAlign: "right", color: "#616161", position: "absolute",
    top: 0, marginBottom: 8
  },
  checklistItemTitle: { fontSize: 16, fontWeight: "bold", color: "#242424" },
  checklistDescription: { fontSize: 16, marginBottom: 16, color: "#424242" },
  estimatedTime: { fontSize: 13, marginBottom: 8, color: "#616161" },
  uploadButton: {
    flexDirection: "row",
    width: 120,
    borderRadius: 8,
    marginBottom: 12,
    marginTop: 16,
    justifyContent: "space-evenly",
    alignItems: "center",
  },
  uploadIcon: { width: 14, height: 18, marginRight: 8 },
  uploadText: { fontSize: 14, fontWeight: "bold", color: "#5B57C7" },
  scanButton: {
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: "#5B57C7",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
    marginTop: 16,
  },
  scanButtonText: { color: "#5B57C7", fontSize: 14, },
  uploadedImageContainer: {
    flexDirection: "row",
    marginBottom: 12,
    alignItems: "center",
  },
  uploadedImage: { width: 100, height: 100, marginRight: 12, marginBottom: 4 },
  imageButtons: { flexDirection: "row", justifyContent: "space-between" },
  icon: { width: 20, height: 20, marginRight: 10 },
  aiAnalyticsContainer: {
    backgroundColor: "#F5F5F5",
    borderRadius: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    padding: 10,
    elevation: 2,
    marginBottom: 20,
    paddingBottom: 20,
  },
  aiDiscriptionContainer: {
    backgroundColor: "#FFF",
    borderRadius: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    padding: 10,
    margin: 10,
    elevation: 2,
    marginBottom: 16,
  },
  rowContainer: {
    flexDirection: "row", // Align items in a row
    alignItems: "center", // Vertically center items
    marginVertical: 8, // Optional vertical spacing
  },
  aiText: { fontSize: 14, fontWeight: "bold", marginLeft: 8, color: "#242424", },
  aiTitle: { fontSize: 16, fontWeight: "bold", marginBottom: 8, color: "#323130" },
  analyticsIcon: {
    width: 30, // Adjust size as needed
    height: 30,
    borderRadius: 4,
    marginRight: 8,
    marginLeft: 16,
  },
  aiDescription: { fontSize: 16, color: "#616161", marginBottom: 8 },
  aiButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
    marginBottom: 40,
  },
  aiButtonsText: {
    fontSize: 16, color: "#616161", marginBottom: 8
  },
  customButton: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 2,
    paddingHorizontal: 8,
    //  gap: 8, // Spacing between elements inside the button
    width: 220,
    height: 22,
    backgroundColor: "#E8EBFA", // Light blue background
    borderRadius: 4, // Rounded corners
    borderWidth: 1, // Border width
    borderColor: "#5B57C7", // Border color
    boxSizing: "border-box",
    marginLeft: 16,
  },
  customButtonText: {
    fontStyle: "normal", // Normal font style
    fontWeight: "400", // Regular weight
    fontSize: 14, // Font size
    lineHeight: 18, // Line height
    display: "flex", // Ensures proper text alignment
    alignItems: "center",
    textAlign: "justify",
    color: "#444791", // Text color
  },
  navigationButtonContainer: {
    // flexDirection: 'row',
    // justifyContent: 'space-between',
    // alignItems: 'center',
    // padding: 20,
    // backgroundColor: '#FFFFFF',
    // shadowColor: '#000', // Shadow color
    // shadowOffset: { width: 0, height: -2 }, // Shadow offset for upper shadow
    // shadowOpacity: 0.05, // Shadow transparency
    // elevation: 2, // Elevation for Android shadow
    // position: 'absolute', // Ensures it's fixed at the bottom
    // bottom: 0, // Align to the bottom of the parent
    // left: 0,
    // right: 0,
    // marginBottom: 0,
    // marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderColor: '#ddd',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  previousButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#fff',
  },
  previousbuttonText: {
    fontSize: 16,
    color: '#5B57C7',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  nextButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    backgroundColor: "#5B57C7",
  },
  navbuttonText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  navButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    backgroundColor: "#5B57C7",
    // backgroundColor: '#5B57C7',
    // padding: 10,
    // borderRadius: 5,
    // alignItems: 'center',
  },
  navbuttonText: {
    color: '#fff',
    fontSize: 16,
  },
  disabledButton: {
    paddingVertical: 10,
    borderColor: '#ccc',
  },
  disabledCompleteButton: {
    // opacity: 0.8,  // Make it semi-transparent
    backgroundColor: '#ccc',
  },
  disabledButtonText: {
    color: '#ccc',
  },
});

export default TaskDetail;
