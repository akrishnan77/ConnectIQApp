import axios from 'axios';
import { KEY, getData } from '../utils/LocalStorage';

const TENENT_ID = "c4a3b92b-74eb-473e-99a1-32d03e0e4632"
const CLIENT_ID = "e7a2c3f7-4f97-4071-b8f8-d47fd6336a06"
const CLIENT_SECRET = "Mpr8Q~kucfIMdgli3ZTLZbb7UZC~dslLJLH53dds"
const SCOPE = "https://service.flow.microsoft.com//.default"
const GRANT_TYPE = "client_credentials"

// Base URL for the API
const BASE_URL = "https://prod-17.centralindia.logic.azure.com:443"; // Replace with your API base URL

// Common axios instance with baseURL
const apiClient = axios.create({
    baseURL: BASE_URL,
    timeout: 25000, // Request timeout (10 seconds)
    headers: {
        'Content-Type': 'application/json',
    },
});

// Function to change the base URL at runtime
const updateBaseUrl = (newBaseUrl) => {
    apiClient.defaults.baseURL = newBaseUrl;
};

// Request interceptor (optional: can be used to add authentication token or handle request logic)
apiClient.interceptors.request.use(
    async (config) => {
        // Add authorization token if necessary
        const token = await getData(KEY.USER_TOKEN); // e.g., get from AsyncStorage or Redux store
        if (token) {
            //console.log('Token Set ', token)
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response interceptor (optional: can be used for global error handling)
apiClient.interceptors.response.use(
    (response) => {
        return response.data; // Return only the response data to make it easier to use
    },
    (error) => {
        const errorMsg = error.response ? error.response.data.message : error.message;
        // You can handle specific error messages globally here, show a notification, etc.
        console.error('API Error:', errorMsg);
        return Promise.reject(errorMsg);
    }
);

// Example API function to fetch user details
export const getAuthToken = async (userId) => {
    const authUrl = "https://prod-28.centralindia.logic.azure.com:443/workflows/075a239ba52c4e19a80d15ba0e6d3bb7/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=44t_UjZxSO6Em7ucsO5F6tmYL7gYtXqNXSBv6TUi-18"
    //const authUrl = "https://cors-anywhere.herokuapp.com/https://login.microsoftonline.com/c4a3b92b-74eb-473e-99a1-32d03e0e4632/oauth2/v2.0/token"
    //const data = 'client_id=e7a2c3f7-4f97-4071-b8f8-d47fd6336a06&scope=https://service.flow.microsoft.com//.default&client_secret=Mpr8Q~kucfIMdgli3ZTLZbb7UZC~dslLJLH53dds&grant_type=client_credentials';

    // const formData = new URLSearchParams();
    // formData.append('client_id', 'e7a2c3f7-4f97-4071-b8f8-d47fd6336a06');
    // formData.append('scope', 'https://service.flow.microsoft.com//.default');
    // formData.append('client_secret', 'Mpr8Q~kucfIMdgli3ZTLZbb7UZC~dslLJLH53dds');
    // formData.append('grant_type', 'client_credentials');

    const requestData = {
        userEmail: userId
    };

    try {
        const response = await axios.post(authUrl, requestData, {
            headers: {
                'Content-Type': 'application/json'
            },
        });

        // console.log('API Service getAuthToken Response');
        // console.log(response.data);

        return response.data;
    } catch (error) {
        console.error('Error getAuthToken:', error);
        throw error;
    }
};

// Example API function to fetch user details
export const getUserDetails = async (userId) => {
    try {
        const response = await apiClient.get(`/users/${userId}`);
        return response;
    } catch (error) {
        throw error;
    }
};

// API function to fetch Dashboard summary data
export const getDashboardDetails = async (type) => {
    const api = '/workflows/d37f0f2f65994c54b3e17d394edcd47e/triggers/manual/paths/invoke?api-version=2016-06-01'

    const loggedInUser = await getData(KEY.USER_EMAIL)
    const requestData = {
        userEmail: loggedInUser,
        dataType: type
    };

    try {
        updateBaseUrl('https://prod-17.centralindia.logic.azure.com:443')
        const response = await apiClient.post(api, requestData)
        console.log('response getDashboardDetails', response)
        return response;
    } catch (error) {
        console.log('Error getDashboardDetails:', error)
        throw error;
    }
};


// API function to fetch Resource URL
export const getResourceUrl = async (resourceId) => {
    const api = '/workflows/39bd3a1c1ef64874b0e80da7f9b354cf/triggers/manual/paths/invoke?api-version=2016-06-01'

    const requestData = {
        id: resourceId
    };

    try {
        updateBaseUrl('https://prod-28.centralindia.logic.azure.com:443')
        const response = await apiClient.post(api, requestData)
        console.log('response getResourceUrl', response)
        return response;
    } catch (error) {
        console.log('Error getResourceUrl:', error)
        throw error;
    }
};

// API function to fetch Dashboard summary data
export const getTaskDetails = async (taskId) => {
    const api = '/workflows/02fc602438a34cf5a2b0b1660dda50e2/triggers/manual/paths/invoke?api-version=2016-06-01'

    const requestData = {
        taskId: taskId
    };

    try {
        updateBaseUrl('https://prod-03.centralindia.logic.azure.com:443')
        const response = await apiClient.post(api, requestData);
        console.log('response getTaskDetails', response)
        return response;
    } catch (error) {
        console.log('Error getTaskDetails:', error)
        throw error;
    }
};

export const uploadChecklistData = async (jsonData, checkListDataArray) => {
    const api = '/workflows/e5fb747564b349a1b7375cfbc18f4026/triggers/manual/paths/invoke?api-version=2016-06-01'
    console.log("checkListDataArray is", checkListDataArray);

    let taskId = parseInt(jsonData.id, 10);
    console.log("taskuploaded id is", taskId);

    const loggedInUser = await getData(KEY.USER_EMAIL)
    const requestData = {
        "id": taskId,
        "role": "Associate",
        "dueDate": "",
        "title": "",
        "taskDescription": "",
        "status": jsonData.status,
        "priority": jsonData.priority,
        "assignee": "",
        "modifiedBy": loggedInUser,
        "taskCategory": "",
        "checklist": checkListDataArray,
    };

    console.log("requestData is here ", requestData);
    //checklist url https://prod-24.centralindia.logic.azure.com:443/workflows/e5fb747564b349a1b7375cfbc18f4026/triggers/manual/paths/invoke?api-version=2016-06-01

    try {
        updateBaseUrl('https://prod-24.centralindia.logic.azure.com:443')
        const response = await apiClient.post(api, requestData);
        console.log('response postChecklistDetails', response)
        return response;
    } catch (error) {
        console.log('Error postChecklistDetails:', error)
        throw error;
    }
};

export const createTaskData = async (jsonData, checkListDataArray) => {
    const api = '/workflows/b3d3b40138b1486ca4d5c9ede0c8f8ca/triggers/manual/paths/invoke?api-version=2016-06-01'
    console.log("checkListDataArray is", checkListDataArray);

    const loggedInUser = await getData(KEY.USER_EMAIL)
    const requestData = {
        "dueDate": jsonData.dueDate,
        "title": jsonData.title,
        "taskDescription": jsonData.taskDescription,
        "status": jsonData.status,
        "priority": jsonData.priority,
        "assignee": jsonData.assignee,
        "createdBy": loggedInUser,
        "taskCategory": jsonData.taskCategory,
        "checklist": checkListDataArray
    };

    console.log("requestData is here ", requestData);
    //checklist url https://prod-24.centralindia.logic.azure.com:443/workflows/e5fb747564b349a1b7375cfbc18f4026/triggers/manual/paths/invoke?api-version=2016-06-01

    try {
        console.log("inside API call")
        updateBaseUrl('https://prod-19.centralindia.logic.azure.com:443')
        const response = await apiClient.post(api, requestData);
        console.log('response postChecklistDetails', response)
        return response;
    } catch (error) {
        console.log('error postChecklistDetails', error)
        throw error;
    }
};

export const editTaskData = async (jsonData, checkListDataArray) => {
    const api = '/workflows/e5fb747564b349a1b7375cfbc18f4026/triggers/manual/paths/invoke?api-version=2016-06-01'
    console.log("checkListDataArray is", checkListDataArray);

    let taskId = parseInt(jsonData.id, 10);
    console.log("taskuploaded id is", taskId);

    const loggedInUser = await getData(KEY.USER_EMAIL)
    const requestData = {
        "id": taskId,
        "role": "Manager",
        "dueDate": jsonData.dueDate,
        "title": jsonData.title,
        "taskDescription": jsonData.taskDescription,
        "status": jsonData.status,
        "priority": jsonData.priority,
        "assignee": jsonData.assignee,
        "modifiedBy": loggedInUser,
        "taskCategory": jsonData.taskCategory,
        "checklist": checkListDataArray,
        // "assignedToName": jsonData.assignedToName,
        // "userName": jsonData.userName,
    };

    console.log("requestData is here ", requestData);
    //checklist url https://prod-24.centralindia.logic.azure.com:443/workflows/e5fb747564b349a1b7375cfbc18f4026/triggers/manual/paths/invoke?api-version=2016-06-01

    try {
        updateBaseUrl('https://prod-24.centralindia.logic.azure.com:443')
        const response = await apiClient.post(api, requestData);
        console.log('response postChecklistDetails', response)
        return response;
    } catch (error) {
        console.log('Error postChecklistDetails:', error)
        throw error;
    }
};

export const assignTrainingData = async (assignedTo, trainingArray) => {
    const api = '/workflows/6b3a1582ef9f4a29a3a5960ebe219115/triggers/manual/paths/invoke?api-version=2016-06-01'
    console.log("assignedTo is", assignedTo);
    console.log("trainingArray is", trainingArray);
    const loggedInUser = await getData(KEY.USER_EMAIL)
    const requestData = {
        "trainingId": trainingArray,
        "status": 0,
        "progressPercentage": 0,
        "dueDate": "2024-12-24",
        "assignedTo": assignedTo,
        "assignedBy": loggedInUser
    }

    try {

        console.log('requestData assignTrainingData', requestData)

        updateBaseUrl('https://prod-25.centralindia.logic.azure.com:443')
        const response = await apiClient.post(api, requestData);
        console.log('response assignTrainingData', response)
        return response;
    } catch (error) {
        console.log('Error assignTrainingData:', error)
        throw error;
    }
};






